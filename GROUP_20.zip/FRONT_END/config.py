credentials = { 
  'host' : "10.17.50.232",
  'port' : "5432",
  'database' : "group_20",
  'user' : "group_20",
  'password' : "ZVOmQK2SdJmMx"
}